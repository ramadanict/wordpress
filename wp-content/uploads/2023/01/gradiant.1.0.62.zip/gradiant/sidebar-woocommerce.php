<?php if ( ! is_active_sidebar( 'gradiant-woocommerce-sidebar' ) ) {	return; } ?>
<div id="av-secondary-content" class="av-column-4 mb-6 mb-av-0 wow fadeInUp">
	<section class="sidebar">
		<?php dynamic_sidebar('gradiant-woocommerce-sidebar'); ?>
	</section>
</div>