<?php if ( ! is_active_sidebar( 'gradiant-sidebar-primary' ) ) {	return; } ?>
<div id="av-secondary-content" class="av-column-4">
	<section class="sidebar">
		<?php dynamic_sidebar('gradiant-sidebar-primary'); ?>
	</section>
</div>